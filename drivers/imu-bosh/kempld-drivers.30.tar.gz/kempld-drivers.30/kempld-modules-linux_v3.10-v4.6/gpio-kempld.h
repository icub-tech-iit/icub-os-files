/*
 *  kempld_gpio.h - Kontron PLD GPIO driver definitions
 *
 *  Copyright (c) 2010-2014 Kontron Europe GmbH
 *  Author: Michael Brunner <michael.brunner@kontron.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License 2 as published
 *  by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

#ifndef _KEMPLD_GPIO_H_
#define _KEMPLD_GPIO_H_

#define KEMPLD_GPIO_MAX_NUM		16

#define KEMPLD_GPIO_MASK(x)		(1<<(x%8))

#define KEMPLD_GPIO_DIR			0x40
#define KEMPLD_GPIO_DIR_NUM(x)		(0x40+x/8)
#define KEMPLD_GPIO_LVL			0x42
#define KEMPLD_GPIO_LVL_NUM(x)		(0x42+x/8)
#define KEMPLD_GPIO_STS			0x44
#define KEMPLD_GPIO_STS_NUM(x)		(0x44+x/8)
#define KEMPLD_GPIO_EVT_LVL_EDGE	0x46
#define KEMPLD_GPIO_EVT_LVL_EDGE_NUM(x)	(0x46+x/8)
#define KEMPLD_GPIO_EVT_LOW_HIGH	0x48
#define KEMPLD_GPIO_EVT_LOW_HIGH_NUM(x)	(0x48+x/8)
#define KEMPLD_GPIO_IEN			0x4A
#define KEMPLD_GPIO_IEN_NUM(x)		(0x4A+x/8)
#define KEMPLD_GPIO_NMIEN		0x4C
#define KEMPLD_GPIO_NMIEN_NUM(x)	(0x4C+x/8)

struct kempld_gpio_data {
	struct gpio_chip		chip;
	int				irq;
	struct kempld_device_data	*pld;
	uint16_t			mask;
#ifdef CONFIG_PM
	uint16_t			dir_save;
	uint16_t			lvl_save;
#endif
};

#endif /* _KEMPLD_GPIO_H_ */
