/*
 *  kempld_now1_gpio.c - Kontron PLD GPIO driver for COMe-mSP1
 *
 *  Copyright (c) 2011-2012 Kontron Europe GmbH
 *  Author: Michael Brunner <michael.brunner@kontron.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License 2 as published
 *  by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

#include <linux/version.h>
#define __NO_VERSION__  /* don't define the kernel version global variable */
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/io.h>
#include <linux/slab.h>
#include <linux/errno.h>
#include <linux/acpi.h>
#include <linux/platform_device.h>
#include <linux/gpio.h>
#include "include/linux/mfd/kempld.h"
#include <linux/seq_file.h>

#include "gpio-kempld.h"

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(4, 5, 0))
#define GPIO_CHIP_DEV	chip->parent
#else
#define GPIO_CHIP_DEV	chip->dev
#endif

#define KEMPLD_NOW1_GPIO_MAX_NUM	8

#define KEMPLD_NOW1_FUNCTION		0x70
#define		KEMPLD_NOW1_FUNCTION_ALF_SDIO	0x01
#define		KEMPLD_NOW1_FUNCTION_USBCC	0x02
#define KEMPLD_NOW1_GPIO_DIR		0xA0
#define KEMPLD_NOW1_GPIO_LVL		0xA1

static int kempld_now1_gpio_get(struct gpio_chip *chip, unsigned offset)
{
	struct kempld_device_data *pld;
	int status;

	pld = dev_get_drvdata(GPIO_CHIP_DEV->parent);

	kempld_get_mutex_set_index(pld, KEMPLD_NOW1_GPIO_LVL);

	status = kempld_read8(pld, KEMPLD_NOW1_GPIO_LVL);

	kempld_release_mutex(pld);

	status &= KEMPLD_GPIO_MASK(offset);

	return status ? 1 : 0;
}

static void kempld_now1_gpio_set(struct gpio_chip *chip, unsigned offset,
			    int value)
{
	struct kempld_device_data *pld;
	int status;

	pld = dev_get_drvdata(GPIO_CHIP_DEV->parent);

	kempld_get_mutex_set_index(pld, KEMPLD_NOW1_GPIO_LVL);

	status = kempld_read8(pld, KEMPLD_NOW1_GPIO_LVL);
	if (value)
		status |= KEMPLD_GPIO_MASK(offset);
	else
		status &= ~KEMPLD_GPIO_MASK(offset);
	kempld_write8(pld, KEMPLD_NOW1_GPIO_LVL, status);

	kempld_release_mutex(pld);
}

static int kempld_now1_gpio_direction_input(struct gpio_chip *chip,
					    unsigned offset)
{
	struct kempld_device_data *pld;
	int status;

	pld = dev_get_drvdata(GPIO_CHIP_DEV->parent);

	kempld_get_mutex_set_index(pld, KEMPLD_NOW1_GPIO_DIR);

	status = kempld_read8(pld, KEMPLD_NOW1_GPIO_DIR);
	status &= ~KEMPLD_GPIO_MASK(offset);
	kempld_write8(pld, KEMPLD_NOW1_GPIO_DIR, status);

	kempld_release_mutex(pld);

	return 0;
}

static int kempld_now1_gpio_direction_output(struct gpio_chip *chip,
					 unsigned offset, int value)
{
	struct kempld_device_data *pld;
	int status;

	pld = dev_get_drvdata(GPIO_CHIP_DEV->parent);

	kempld_get_mutex_set_index(pld, KEMPLD_NOW1_GPIO_DIR);

	status = kempld_read8(pld, KEMPLD_NOW1_GPIO_LVL);
	if (value)
		status |= KEMPLD_GPIO_MASK(offset);
	else
		status &= ~KEMPLD_GPIO_MASK(offset);
	kempld_write8(pld, KEMPLD_NOW1_GPIO_LVL, status);

	status = kempld_read8(pld, KEMPLD_NOW1_GPIO_DIR);
	status |= KEMPLD_GPIO_MASK(offset);
	kempld_write8(pld, KEMPLD_NOW1_GPIO_DIR, status);

	kempld_release_mutex(pld);

	return 0;
}

#ifdef CONFIG_DEBUG_FS
static int kempld_now1_gpio_get_direction(struct gpio_chip *chip,
					  unsigned offset)
{
	struct kempld_device_data *pld;
	int status;

	pld = dev_get_drvdata(GPIO_CHIP_DEV->parent);

	kempld_get_mutex_set_index(pld, KEMPLD_NOW1_GPIO_DIR);

	status = kempld_read8(pld, KEMPLD_NOW1_GPIO_DIR);

	kempld_release_mutex(pld);

	status &= KEMPLD_GPIO_MASK(offset);

	return status ? 1 : 0;
}

static void kempld_now1_gpio_dbg_show(struct seq_file *s,
				      struct gpio_chip *chip)
{
	struct kempld_device_data *pld;
	int function;
	int i;

	pld = dev_get_drvdata(GPIO_CHIP_DEV->parent);

	kempld_get_mutex_set_index(pld, KEMPLD_NOW1_FUNCTION);

	function = kempld_read8(pld, KEMPLD_NOW1_FUNCTION);

	kempld_release_mutex(pld);

	for (i = 0; i < chip->ngpio; i++) {
		int gpio = i + chip->base;

		seq_printf(s, " gpio-%-3d %s %s %s\n", gpio,
			   kempld_now1_gpio_get_direction(chip, i)
			   ? "out" : "in",
			   kempld_now1_gpio_get(chip, i) ? "hi" : "lo",
			   function & KEMPLD_NOW1_FUNCTION_ALF_SDIO ? "sdio" :
			   ((function & KEMPLD_NOW1_FUNCTION_USBCC)
			    && (i == 0)) ? "usbcc" : "gpio");
	}
}
#else
#define kempld_now1_gpio_dbg_show NULL
#endif

static int kempld_now1_gpio_probe(struct platform_device *pdev)
{
	struct device *dev = &pdev->dev;
	struct kempld_device_data *pld;
	struct gpio_chip *chip;
	int function;
	int ret;

	pld = dev_get_drvdata(dev->parent);

	chip = devm_kzalloc(dev, sizeof(struct gpio_chip), GFP_KERNEL);
	if (chip == NULL)
		return -ENOMEM;

	chip->label =		"kempld_now1-gpio";
	chip->owner =		THIS_MODULE;
	chip->can_sleep =	1;
	GPIO_CHIP_DEV =		dev;
	chip->base =		-1;
	chip->ngpio =		KEMPLD_NOW1_GPIO_MAX_NUM;

	chip->direction_input =		kempld_now1_gpio_direction_input;
	chip->direction_output =	kempld_now1_gpio_direction_output;
	chip->get =			kempld_now1_gpio_get;
	chip->set =			kempld_now1_gpio_set;
	chip->dbg_show =		kempld_now1_gpio_dbg_show;

	kempld_get_mutex_set_index(pld, KEMPLD_NOW1_FUNCTION);

	function = kempld_read8(pld, KEMPLD_NOW1_FUNCTION);

	kempld_release_mutex(pld);

	if (function & KEMPLD_NOW1_FUNCTION_ALF_SDIO)
		dev_warn(&pdev->dev, "GPIO pins are used for SDIO\n");
	if (function & KEMPLD_NOW1_FUNCTION_USBCC) {
		dev_info(&pdev->dev,
			 "GPI[0] is forwarded to USB cable connect\n");
	}

	platform_set_drvdata(pdev, chip);

	ret = gpiochip_add(chip);
	if (ret) {
		dev_err(&pdev->dev, "Could not register GPIO chip\n");
		return ret;
	}

	dev_info(&pdev->dev, "GPIO functionality initialized\n");

	return 0;
}

static int kempld_now1_gpio_remove(struct platform_device *pdev)
{
	struct gpio_chip *chip = platform_get_drvdata(pdev);

	gpiochip_remove(chip);

	return 0;
}

static struct platform_driver kempld_now1_gpio_driver = {
	.driver = {
		.name = "kempld_now1-gpio",
		.owner = THIS_MODULE,
	},
	.probe		= kempld_now1_gpio_probe,
	.remove		= kempld_now1_gpio_remove,
};

static int __init kempld_now1_gpio_init(void)
{
	return platform_driver_register(&kempld_now1_gpio_driver);
}

static void __exit kempld_now1_gpio_exit(void)
{
	platform_driver_unregister(&kempld_now1_gpio_driver);
}

module_init(kempld_now1_gpio_init);
module_exit(kempld_now1_gpio_exit);

MODULE_DESCRIPTION("KEM PLD nanoETXexpress-SP GPIO Driver");
MODULE_AUTHOR("Michael Brunner <michael.brunner@kontron.com>");
MODULE_LICENSE("GPL");
MODULE_ALIAS("platform:kempld_now1-gpio");
MODULE_VERSION("30.0");
