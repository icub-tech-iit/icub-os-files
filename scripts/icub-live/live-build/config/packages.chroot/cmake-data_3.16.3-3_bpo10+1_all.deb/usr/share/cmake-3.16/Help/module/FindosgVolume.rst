.. cmake-module:: ../../Modules/FindosgVolume.cmake
