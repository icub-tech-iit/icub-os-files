.. cmake-module:: ../../Modules/FindProducer.cmake
