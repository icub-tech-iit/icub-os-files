Precompiled binary syslinux files were extracted from http://free.nchc.org.tw/syslinux/syslinux-6.03.tar.xz
